#include <iostream>
#include <fstream>
#include <iomanip>
#include <vector>

using namespace std;

// Structure to store contact information
struct Contact {
    string name;
    string phoneNumber;
    string email;
};

// Function to add a new contact
void addContact(vector<Contact>& contacts) {
    Contact newContact;
    cout << "Enter name: ";
    cin.ignore();
    getline(cin, newContact.name);

    // Check for duplicate names
    for (const auto& contact : contacts) {
        if (contact.name == newContact.name) {
            cout << "Contact with the same name already exists!" << endl;
            return;
        }
    }

    cout << "Enter phone number: ";
    getline(cin, newContact.phoneNumber);
    cout << "Enter email: ";
    getline(cin, newContact.email);
    contacts.push_back(newContact);
    cout << "Contact added successfully!" << endl;
}

// Function to display all contacts
void displayContacts(const vector<Contact>& contacts) {
    cout << "----------------------------------------------" << endl;
    cout << setw(20) << "Name" << setw(20) << "Phone Number" << setw(30) << "Email" << endl;
    cout << "----------------------------------------------" << endl;
    for (const auto& contact : contacts) {
        cout << setw(20) << contact.name << setw(20) << contact.phoneNumber << setw(30) << contact.email << endl;
    }
    cout << "----------------------------------------------" << endl;
}

// Function to search for a contact by name
int searchContactByName(const vector<Contact>& contacts, const string& name) {
    for (int i = 0; i < contacts.size(); i++) {
        if (contacts[i].name == name) {
            return i;
        }
    }
    return -1;
}

// Function to search for a contact by email
int searchContactByEmail(const vector<Contact>& contacts, const string& email) {
    for (int i = 0; i < contacts.size(); i++) {
        if (contacts[i].email == email) {
            return i;
        }
    }
    return -1;
}

// Function to search for a contact by phone number
int searchContactByPhoneNumber(const vector<Contact>& contacts, const string& phoneNumber) {
    for (int i = 0; i < contacts.size(); i++) {
        if (contacts[i].phoneNumber == phoneNumber) {
            return i;
        }
    }
    return -1;
}

// Function to search for a contact by name
void searchContactByName(const vector<Contact>& contacts) {
    string searchName;
    cout << "Enter name to search: ";
    cin.ignore();
    getline(cin, searchName);
    int index = searchContactByName(contacts, searchName);
    if (index != -1) {
        cout << "Contact found!" << endl;
        cout << "Name: " << contacts[index].name << endl;
        cout << "Phone Number: " << contacts[index].phoneNumber << endl;
        cout << "Email: " << contacts[index].email << endl;
    } else {
        cout << "Contact not found!" << endl;
    }
}

// Function to search for a contact by email
void searchContactByEmail(const vector<Contact>& contacts) {
    string searchEmail;
    cout << "Enter email to search: ";
    cin.ignore();
    getline(cin, searchEmail);
    int index = searchContactByEmail(contacts, searchEmail);
    if (index != -1) {
        cout << "Contact found!" << endl;
        cout << "Name: " << contacts[index].name << endl;
        cout << "Phone Number: " << contacts[index].phoneNumber << endl;
        cout << "Email: " << contacts[index].email << endl;
    } else {
        cout << "Contact not found!" << endl;
    }
}

// Function to search for a contact by phone number
void searchContactByPhoneNumber(const vector<Contact>& contacts) {
    string searchPhoneNumber;
    cout << "Enter phone number to search: ";
    cin.ignore();
    getline(cin, searchPhoneNumber);
    int index = searchContactByPhoneNumber(contacts, searchPhoneNumber);
    if (index != -1) {
        cout << "Contact found!" << endl;
        cout << "Name: " << contacts[index].name << endl;
        cout << "Phone Number: " << contacts[index].phoneNumber << endl;
        cout << "Email: " << contacts[index].email << endl;
    } else {
        cout << "Contact not found!" << endl;
    }
}

// Function to update a contact
void updateContact(vector<Contact>& contacts) {
    string searchName;
    cout << "Enter name to update: ";
    cin.ignore();
    getline(cin, searchName);
    int index = searchContactByName(contacts, searchName);
    if (index != -1) {
        cout << "Enter new phone number: ";
        getline(cin, contacts[index].phoneNumber);
        cout << "Enter new email: ";
        getline(cin, contacts[index].email);
        cout << "Contact updated successfully!" << endl;
    } else {
        cout << "Contact not found!" << endl;
    }
}

// Function to delete a contact
void deleteContact(vector<Contact>& contacts) {
    string searchName;
    cout << "Enter name to delete: ";
    cin.ignore();
    getline(cin, searchName);
    int index = searchContactByName(contacts, searchName);
    if (index != -1) {
        contacts.erase(contacts.begin() + index);
        cout << "Contact deleted successfully!" << endl;
    } else {
        cout << "Contact not available!" << endl;
    }
}

// Function to save contact data to a file
void saveData(const vector<Contact>& contacts) {
    ofstream outFile("contact_data.txt");
    if (outFile.is_open()) {
        for (const auto& contact : contacts) {
            outFile << contact.name << "," << contact.phoneNumber << "," << contact.email << endl;
        }
        outFile.close();
        cout << "Data saved successfully!" << endl;
    } else {
        cout << "Unable to open file!" << endl;
    }
}

// Function to load contact data from a file
void loadData(vector<Contact>& contacts) {
    ifstream inFile("contact_data.txt");
    if (inFile.is_open()) {
        contacts.clear();
        string line;
        while (getline(inFile, line)) {
            Contact contact;
            size_t pos = line.find(",");
            contact.name = line.substr(0, pos);
            line.erase(0, pos + 1);
            pos = line.find(",");
            contact.phoneNumber = line.substr(0, pos);
            line.erase(0, pos + 1);
            contact.email = line;
            contacts.push_back(contact);
        }
        inFile.close();
        cout << "Data loaded successfully!" << endl;
    } else {
        cout << "Unable to open file!" << endl;
    }
}

int main() {
    vector<Contact> contacts;
    loadData(contacts);

    int choice;
    do {
        cout << "-------------------------" << endl;
        cout << "Contact Management System" << endl;
        cout << "-------------------------" << endl;
        cout << "1. Add Contact" << endl;
        cout << "2. Display Contacts" << endl;
        cout << "3. Update Contact" << endl;
        cout << "4. Delete Contact" << endl;
        cout << "5. Search Contact by Name" << endl;
        cout << "6. Search Contact by Email" << endl;
        cout << "7. Search Contact by Phone Number" << endl;
        cout << "8. Save Data" << endl;
        cout << "9. Exit" << endl;
        cout << "-------------------------" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                addContact(contacts);
                break;
            case 2:
                displayContacts(contacts);
                break;
            case 3:
                updateContact(contacts);
                break;
            case 4:
                deleteContact(contacts);
                break;
            case 5:
                searchContactByName(contacts);
                break;
            case 6:
                searchContactByEmail(contacts);
                break;
            case 7:
                searchContactByPhoneNumber(contacts);
                break;
            case 8:
                saveData(contacts);
                break;
            case 9:
                cout << "Exiting..." << endl;
                break;
            default:
                cout << "Invalid choice! Please try again." << endl;
        }
    } while (choice != 9);

    return 0;
}

